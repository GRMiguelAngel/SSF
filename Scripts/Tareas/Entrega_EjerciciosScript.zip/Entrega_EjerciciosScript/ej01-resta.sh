#!/bin/bash
########################################################################
#
#   Autor: Miguel Ángel García Rodríguez <miguelangel2e2005@gmail.com>
#
#   Objetivo: Realizar resta. 
#
#   Entrada: Números
#
#   Salida: Mostrar resta.
#
#   Versión: 1
#
########################################################################

resultado=$(($1-$2))
echo "El resultado de restar $1 y $2 es $resultado"