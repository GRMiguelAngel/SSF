#!/bin/bash

NIF=$1
Nombre=$2
Apellido=$3
Usuario=$4
echo 'Bienvenido, '$Nombre
echo "Tus datos son: $NIF, $Nombre $Apellido"
echo "Vamos a usar tu usuario: $Usuario"
echo "Tu nueva id es: $RANDOM"
